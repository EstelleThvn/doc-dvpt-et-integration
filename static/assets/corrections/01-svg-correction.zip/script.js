document.addEventListener("DOMContentLoaded", () => {
    // ==== Q14. ==== //
    const svg = document.querySelector("svg.histogramme");

    /* Créer les axes avec line :
    svg.innerHTML += `<line class="axe-horizontal" style="stroke:black;" x1="0" y1="100" x2="100" y2="100" />
                    <line class="axe-horizontal" style="stroke:black;" x1="0" y1="100" x2="0" y2="0" />`;
    */

    /* Créer les axes avec rect : 
    svg.innerHTML += `<rect class="axe-horizontal" style="fill:black;" x="0" y="99" width="100" height="1" />
                    <rect class="axe-horizontal" style="fill:black;" x="0" y="0" width="1" height="100" />`
    */

    /* Ou créer les axes avec path : */
    svg.innerHTML += `<path class="axe-horizontal" style="stroke:black;" d="M 0 100 L 100 100" />
                    <path class="axe-vertical" style="stroke:black;" d="M 0 100 L 0 0" />`;


    // ==== Q15. ==== //
    // Avec path :
    // svg.innerHTML += `<path class="barre" data-value="100" style="fill:blue;fill-opacity:0.5;transform:translateY(100%)scale(1,-1);" d="M 0 0 L 10 0 L 10 100 L 0 100 L 0 0" />`;

    // Avec rect :
    svg.innerHTML += `<rect class="barre" data-value="100" style="fill:blue;fill-opacity:0.5;transform:translateY(100%)scale(1,-1);" x="0" y="0" width="10" height="100" />`;

    // On utilise transform:translateY(100%)scale(1,-1); pour retourner l'élément verticalement et le replacer sur l'abscisse en bas


    // ==== Q16. ==== //
    /* Avec path :
    svg.innerHTML += `<path class="barre" data-value="50" style="fill:blue;fill-opacity:0.5;transform:translateY(100%)scale(1,-1);" d="M 20 0 L 30 0 L 30 50 L 20 50 L 20 0" />`;
    svg.innerHTML += `<path class="barre" data-value="90" style="fill:blue;fill-opacity:0.5;transform:translateY(100%)scale(1,-1);" d="M 40 0 L 50 0 L 50 90 L 40 90 L 40 0" />`;
    svg.innerHTML += `<path class="barre" data-value="10" style="fill:blue;fill-opacity:0.5;transform:translateY(100%)scale(1,-1);" d="M 60 0 L 70 0 L 70 10 L 60 10 L 60 0" />`;
    svg.innerHTML += `<path class="barre" data-value="50" style="fill:blue;fill-opacity:0.5;transform:translateY(100%)scale(1,-1);" d="M 80 0 L 90 0 L 90 50 L 80 50 L 80 0" />`;
    */

    /* Avec rect : */
    svg.innerHTML += `<rect class="barre" data-value="50" style="fill:blue;fill-opacity:0.5;transform:translateY(100%)scale(1,-1);" x="20" y="0" width="10" height="50" />`;
    svg.innerHTML += `<rect class="barre" data-value="90" style="fill:blue;fill-opacity:0.5;transform:translateY(100%)scale(1,-1);" x="40" y="0" width="10" height="90" />`;
    svg.innerHTML += `<rect class="barre" data-value="10" style="fill:blue;fill-opacity:0.5;transform:translateY(100%)scale(1,-1);" x="60" y="0" width="10" height="10" />`;
    svg.innerHTML += `<rect class="barre" data-value="50" style="fill:blue;fill-opacity:0.5;transform:translateY(100%)scale(1,-1);" x="80" y="0" width="10" height="50" />`;


    // ==== Q18. ==== //
    const infobulle = document.querySelector(".infobulle");
    svg.querySelectorAll(".barre").forEach(barre => {
        barre.addEventListener("mouseover", function() {
            infobulle.innerHTML = barre.getAttribute('data-value');
        });
        barre.addEventListener("mouseleave", function() {
            infobulle.innerHTML = "";
        });
    });


    // ==== Q19. ==== //
    function dessineAxes(svgId, largeur, hauteur) {
        const svgElement = document.getElementById(svgId);

        /* Créer les axes avec line : 
        svgElement.innerHTML = `<line class="axe-horizontal" style="stroke:black;" x1="0" y1="${hauteur}" x2="${largeur}" y2="${hauteur}" />
                        <line class="axe-horizontal" style="stroke:black;" x1="0" y1="${hauteur}" x2="0" y2="0" />`;
        */

        /* Ou créer les axes avec path : */
        svgElement.innerHTML = `<path class="axe-horizontal" style="stroke:black;" d="M 0 ${hauteur} L ${largeur} ${hauteur}" />
                                <path class="axe-vertical" style="stroke:black;" d="M 0 ${hauteur} L 0 0" />`;
    }

    // ==== Q20. ==== //
    function dessineBarre(svgId, numeroBarre, hauteurBarre, largeurBarre, espacementBarre, couleur) {
        const svgElement = document.getElementById(svgId);

        /* Créer les barres avec rect : 
        svgElement.innerHTML += `<rect class="barre" data-value=${hauteurBarre} style="fill:${couleur};fill-opacity:0.5;transform:translateY(100%)scale(1,-1);"  x="${numeroBarre * largeurBarre + numeroBarre * espacementBarre}" y="0" width="${largeurBarre}" height="${hauteurBarre}" />`;
        */


        /* Ou créer les barres avec path : */
        const xBarre = numeroBarre * largeurBarre + numeroBarre * espacementBarre;
        const xEspacementBarre = xBarre + largeurBarre;

        svgElement.innerHTML += `<path class="barre" data-value=${hauteurBarre} style="fill:${couleur};fill-opacity:0.5;transform:translateY(100%)scale(1,-1);" d="M ${xBarre} 0 L ${xEspacementBarre} 0 L ${xEspacementBarre} ${hauteurBarre} L ${xBarre} ${hauteurBarre} L ${xBarre} 0" />`;
    }


    // ==== Q21. ==== //
    // on définit une valeur par défaut pour la couleur : si la couleur n'est pas donnée dans l'appel de la fonction, la couleur par défaut sera "red"
    function dessineHistogramme(svgId, largeurHistogramme, hauteurHistogramme, donnees, largeurBarre, espacementBarre, couleur = "red") {
        // initialise la viewBox en fonction de la width et height de l'histogramme
        document.getElementById(svgId).setAttribute('viewBox', `0 0 ${largeurHistogramme} ${hauteurHistogramme}`);

        dessineAxes(svgId, largeurHistogramme, hauteurHistogramme);

        // Dessiner les barres - solution n°1 : dessiner les barres avec les valeurs d'origine
        donnees.forEach((valeur, index) => {
            dessineBarre(svgId, index, valeur, largeurBarre, espacementBarre, couleur);
        });

        // Dessiner les barres - solution n°2 : Si on souhaite adapter la hauteur des barres à la hauteur de l'histogramme, pour que la plus grande barre soit au maximum de la hauteur de l'histogramme
        /*
        const maximum = Math.max(...donnees);
        // La syntaxe de décomposition ... décompose le tableau de données en chacune de ses valeurs, pour pouvoir toutes les passer en paramètre de Math.max()

        const donneesAdaptees = donnees.map(valeur => (valeur/maximum) * hauteurHistogramme);
        // .map() retourne un nouveau tableau contenant les résultats de l'appel de la fonction passée en argument sur chaque élément du tableau. Ici, chaque valeur est transformée et devient (valeur/maximum) * hauteurHistogramme

        donneesAdaptees.forEach((valeur, index) => {
            dessineBarre(svgId, index, valeur, largeurBarre, espacementBarre, couleur);
        });
        */
    }

    const barres = [100,50,90,10,50];
    dessineHistogramme("histogrammeParametrable", 120, 120, barres, 10, 10, "blue");


    // ==== Q22. ==== //
    // On passe toutes les barres à une hauteur de 0
    document.querySelectorAll(".barre").forEach(barre => {
        barre.style.transform = "translateY(100%) scale(1,0)";
    });


    // Solution n°1 : Transition CSS
    /*
    // On utilise setTimeout(fonction,0) pour s'assurer que les changements dans la page web suite à l'ajout des barres dans le svg avec leurs hauteur de 0 aient bien fini avant de lancer la transition CSS avec la valeur finale
    setTimeout(function(){
        document.querySelectorAll(".barre").forEach(barre => {
            barre.style.transition = '2s ease-in-out';
            barre.style.transform = 'translateY(100%) scale(1,-1)';
        })
    }, 0);
    */

    // Solution n°2 : .animate() en JS
    document.querySelectorAll(".barre").forEach(barre => {
        let redimensionnementProgressif = barre.animate({transform:'translateY(100%) scale(1,-1)'},2000);
        redimensionnementProgressif.addEventListener('finish', function(){
            barre.style.transform = 'translateY(100%) scale(1,-1)';
        });
    });

    // À savoir : Si vous avez utilisé rect, vous pouvez changer la propriété css height de 0 à barre.getAttribute('data-value') à la place du scale de scale(1,0) à scale(1,-1). Cette solution en modifiant height ne marche pas avec path.
    /*
    document.querySelectorAll(".barre").forEach(barre => {
        barre.style.height = "0";
    });
    document.addEventListener("DOMContentLoaded", () => {
        setTimeout(function(){
            document.querySelectorAll(".barre").forEach(barre => {
                barre.style.transition = '2s ease-in-out';
                barre.style.height = `${barre.getAttribute('data-value')}px`;
            })
        }, 0);
    });
    */
});