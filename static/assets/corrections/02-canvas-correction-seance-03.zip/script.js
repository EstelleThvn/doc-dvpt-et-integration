document.addEventListener("DOMContentLoaded", () => {
    // ==== Q3. ==== //
    const canvas = document.getElementById("canvas");
    const ctx = canvas.getContext("2d");
    // ctx.fillStyle = "green";
    // ctx.fillRect(0, 0, 100, 100);

    // ==== Q4. ==== //
    function dessineAxes(contexte, largeur, hauteur) {
        contexte.fillStyle = "black";
        contexte.beginPath();
        contexte.moveTo(0, 0);
        contexte.lineTo(0, hauteur);
        contexte.lineTo(largeur, hauteur);
        contexte.stroke();
    }

    function dessineBarre(contexte, numeroBarre, hauteurHistogramme, hauteurBarre, largeurBarre, espacementBarre, couleur) {
        const xBarre = numeroBarre * largeurBarre + numeroBarre * espacementBarre;

        contexte.globalAlpha = 0.5;
        contexte.fillStyle = couleur;
        contexte.fillRect(xBarre, hauteurHistogramme-hauteurBarre, largeurBarre, hauteurBarre);
    }

    function dessineHistogramme(contexte, largeurHistogramme, hauteurHistogramme, donnees, largeurBarre, espacementBarre, couleur = "red") {
        dessineAxes(contexte, largeurHistogramme, hauteurHistogramme);

        donnees.forEach((valeur, index) => {
            dessineBarre(contexte, index, hauteurHistogramme, valeur, largeurBarre, espacementBarre, couleur);
        });
    }

    dessineHistogramme(ctx, 100, 100, [100,50,90,10,50], 10, 10, "blue");


    // ==== Q5. ==== //
    let img = new Image();
    img.src = "./media/Jardim_de_Infância_Ernestina_Pessoa_Vitória_Espírito_Santo_Tiles_2019-5130.jpg";

    img.addEventListener("load", function () {
        const canvas = document.getElementById("image");
        const ctx = canvas.getContext("2d");
        ctx.drawImage(img, 0, 0, 320, 213);
    });
});