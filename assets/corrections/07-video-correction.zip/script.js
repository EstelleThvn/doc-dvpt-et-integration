// Licence MIT (c) Philippe Gambette - 2024
// Q3. Detection of the click on the play button
document.querySelector("#play").addEventListener("click", e => {
    // Launch of both videos
    document.querySelector(".video-top video").play();
    document.querySelector(".video-bottom video").play();
 })
 
 
// Q4. Detection that the first video is played
let videoTimer;
let duration;

document.querySelector(".video-top video").addEventListener("play", e => {
duration = document.querySelector(".video-bottom video").duration;
// Start the fading to white effect
videoTimer = setInterval(e=>{
    // Selector of the top video to extract information (about the running time)
    let currentTime = document.querySelector(".video-top video").currentTime;
    // Changing opacity for the fading to white effect
    if(currentTime < 1){
        document.querySelector(".mask").style.opacity=1-currentTime;
    }
    if(currentTime > 1){
        document.querySelector(".mask").style.opacity=0;
        // Stop the timer (Q4.)
        // clearInterval(videoTimer);
    }
    

    // Q5. When the bottom video is ending, make it disappear by decreasing its height
    console.log(currentTime > duration);
    console.log(currentTime, duration);
    if((currentTime > duration-5) && (currentTime < duration)){
        // Solution n°1
        document.querySelector(".video-top").style.height=250-125*(duration - currentTime)/5+"px";
        document.querySelector(".video-bottom").style.top=250-125*(duration - currentTime)/5+"px";
        document.querySelector(".video-split").style.top=250-125*(duration - currentTime)/5+"px";

        // Solution n°2
        /*
        // When the currenTime is comprised in the last 5 seconds of the video, multiplier is between 0 and 1. We use it to multiply 125, to increase or decrease the height of the videos from 0px to 125px.
        let multiplier = (currentTime - (duration-5)) / 5;
        console.log(multiplier);
        document.querySelector(".video-top").style.height = 125 + 125*multiplier + "px";
        document.querySelector(".video-bottom").style.top = 125 + 125*multiplier + "px";
        document.querySelector(".video-split").style.top = 125 + 125*multiplier + "px";
        */
    }
    if(currentTime > duration) {
        document.querySelector(".video-top").style.height = "250px";
        document.querySelector(".video-bottom").style.top = "250px";
        document.querySelector(".video-split").style.top = "250px";
        clearInterval(videoTimer);
    }
}, 50)
});