document.addEventListener("DOMContentLoaded", function () {
    // ==== Q3. ==== //
    const playlist = [
        {
            name: "Chopin_Sonata_no_2_4th_movement.ogg",
            title: "Sonata no 2 4th movement",
            author: "Chopin",
            url: "https://upload.wikimedia.org/wikipedia/commons/e/e7/Chopin_Sonata_no_2_4th_movement.ogg"
        },
        {
            name: "Bach_Emaj_Violin_Concerto_-_3._Allegro.ogg",
            title: "Emaj Violin Concerto - 3. Allegro",
            author: "Bach",
            url: "https://upload.wikimedia.org/wikipedia/commons/f/f5/Bach_Emaj_Violin_Concerto_-_3._Allegro.ogg"
        },
        {
            name: "Beethoven_op37_cad.ogg",
            title: "op37 cad",
            author: "Beethoven",
            url: "https://upload.wikimedia.org/wikipedia/commons/3/33/Beethoven_op37_cad.ogg"
        },
    ];


    // ==== Q4. ==== //
    let soundNumber = 0;


    // ==== Q5. ==== //
    const audio = document.getElementById("audio");

    const playMusic = () => {
        audio.src = `./media/${playlist[soundNumber].name}`;
        audio.play();

        // Pour la Q12 et Q13 :
        audio.volume = 1
        // ---
    };

    const playBtn = document.getElementById('play');
    playBtn.addEventListener('click', function() {
        playMusic();
    });


    // ==== Q6. ==== //
    //Le code est commenté car optimisé à la Q12. et Q13.
    /*
    const pauseMusic = () => {
        audio.pause();
    };
    
    const pauseBtn = document.getElementById('pause');
    pauseBtn.addEventListener('click', function() {
        pauseMusic();
    });
    */


    // ==== Q7. ==== //
    //Le code est commenté car optimisé à la Q10.
    /*
    const goToNext10Sec = () => {
        audio.currentTime+=10;
    };

    const next10SecondsBtn = document.getElementById('next-ten-seconds');
    next10SecondsBtn.addEventListener('click', function() {
        goToNext10Sec();
    });
    */

    
    // ==== Q8. ==== //
    const nextMusic = () => {
        audio.pause();
        soundNumber = soundNumber < playlist.length-1 ? soundNumber+1 : 0;
        audio.src = `./media/${playlist[soundNumber].name}`;
        audio.currentTime = 0;
        audio.play();
    };

    const nextBtn = document.getElementById('next');
    nextBtn.addEventListener('click', function() {
        nextMusic();
    });


    // ==== Q9. ==== //
    const prevMusic = () => {
        audio.pause();
        soundNumber = soundNumber > 0 ? soundNumber-1 : playlist.length-1;
        audio.src = `./media/${playlist[soundNumber].name}`;
        audio.currentTime = 0;
        audio.play();
    };

    const prevBtn = document.querySelector('button#prev');
    prevBtn.addEventListener('click', function() {
        prevMusic();
    });


    // ==== Q10. ==== //
    const goToNext10Sec = () => {
        if(audio.currentTime+10 >= audio.duration){
            nextMusic();
        }
        else {
            audio.currentTime+=10;
        }
    };

    const next10SecondsBtn = document.getElementById('next-ten-seconds');
    next10SecondsBtn.addEventListener('click', function() {
        goToNext10Sec();
    });


    // ==== Q11. ==== //
    const toggleMusic = (button) => {
        if(audio.paused) {
            audio.src = `./media/${playlist[soundNumber].name}`;
            button.innerHTML = "⏸";
            audio.play();

            // Pour la Q12 et Q13 :
            audio.volume = 1
            // ---
        }
        else {
            button.innerHTML = "⏵";
            audio.pause();
        }
    };

    const toggleBtn = document.getElementById('toggle');
    toggleBtn.addEventListener('click', function() {
        toggleMusic(toggleBtn);
    });


    // ==== Q12. ==== //
    // Code commenté car amélioré à la Q13.
    /*
    const fadeOutMusic = () => {   
        const fadeSpeed = 0.1;

        const fadeOutInterval = setInterval(function() { 
            if (audio.volume == 0) {
                audio.pause();
                // Stop setInterval quand on atteint 0
                clearInterval(fadeOutInterval);
            }
        }, 100);
    }

    const pauseBtn = document.getElementById('pause');
    pauseBtn.addEventListener('click', function() {
        fadeOutMusic();
    });
    */

   
    // ==== Q13. ==== //
    const fadeOutMusic = () => {   
        const fadeSpeed = 0.1;

        const fadeOutInterval = setInterval(function() { 
            if (audio.volume == 0) {
                audio.pause();
                // Stop setInterval quand on atteint 0
                clearInterval(fadeOutInterval);
            }
            else {
                audio.volume = audio.volume < fadeSpeed ? 0 : audio.volume - fadeSpeed ;
            }
        }, 100);
    }

    const pauseBtn = document.getElementById('pause');
    pauseBtn.addEventListener('click', function() {
        fadeOutMusic();
    });
});