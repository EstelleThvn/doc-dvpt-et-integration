// Solutions fournies par Estelle Thouvenin pour les questions Q1 à Q6 et questions Bonus, par Philippe Gambette pour la question Q7

document.addEventListener("DOMContentLoaded", () => {
    // ==== Q3. ==== //
    const canvas = document.getElementById("canvas");
    const ctx = canvas.getContext("2d");

    // ==== QUESTION BONUS. MODIFIER LA RESOLUTION DU CANVAS ==== //
    function setCanvasToCorrectResolution (canvas, dpr) {
        const rect = canvas.getBoundingClientRect();

        // On change la taille du canvas par sa taille "réelle"
        canvas.width = rect.width * dpr;
        canvas.height = rect.height * dpr;
        // on zoome le context pour que nos éléments du canvas soient à la bonne taille
        canvas.getContext("2d").scale(dpr, dpr);
        // On change la taille dessiné du canvas, la taille qui sera dans la page web
        canvas.style.width = `${rect.width}px`;
        canvas.style.height = `${rect.height}px`;
    };
    // récupère le ratio de la résolution et la taille du canvas
    const dpr = window.devicePixelRatio;

    //Décommenter les deux lignes suivantes pour modifier la résolution des canvas en fonction de la résolution d'écran de l'utilisateur (commenté pour la Q7.)
    // setCanvasToCorrectResolution(canvas, dpr);
    // setCanvasToCorrectResolution(document.getElementById("image"), dpr);
    // ========================= //

    // ==== SUITE Q3. ==== //
    // ctx.fillStyle = "green";
    // ctx.fillRect(0, 0, 100, 100);

    // ==== Q4. ==== //
    function dessineAxes(contexte, largeur, hauteur) {
        // Q4 : dessin d'une ligne
        contexte.fillStyle = "black";
        contexte.beginPath();
        contexte.moveTo(0, 0);
        contexte.lineTo(0, hauteur);
        contexte.lineTo(largeur, hauteur);
        contexte.stroke();
    }

    function dessineBarre(contexte, numeroBarre, hauteurHistogramme, hauteurBarre, largeurBarre, espacementBarre, couleur) {
        const xBarre = numeroBarre * largeurBarre + numeroBarre * espacementBarre;

        contexte.globalAlpha = 0.5;
        contexte.fillStyle = couleur;
        // Q4 : dessin d'un rectangle
        contexte.fillRect(xBarre, hauteurHistogramme-hauteurBarre, largeurBarre, hauteurBarre);
    }

    function dessineHistogramme(contexte, largeurHistogramme, hauteurHistogramme, donnees, largeurBarre, espacementBarre, couleur = "red") {
        dessineAxes(contexte, largeurHistogramme, hauteurHistogramme);

        donnees.forEach((valeur, index) => {
            dessineBarre(contexte, index, hauteurHistogramme, valeur, largeurBarre, espacementBarre, couleur);
        });
    }

    dessineHistogramme(ctx, 100, 100, [100,50,90,10,50], 10, 10, "blue");


    // ==== Q5. ==== //
    let img = new Image();
    img.src = "./media/Jardim_de_Infância_Ernestina_Pessoa_Vitória_Espírito_Santo_Tiles_2019-5130.jpg";

    img.addEventListener("load", function () {
        const canvas = document.getElementById("image");
        const ctx = canvas.getContext("2d");
        ctx.drawImage(img, 0, 0, 320, 213);

        
        // ==== Q6. ==== //

        // SOLUTION N°1 : Une seule boucle qui parcourt le tableau de valeurs rgba de tous les pixels composant l'image
        /*
        // On récupère les valeurs rgba de tous les pixels de l'image
        const imgWidth = canvas.width;
        const imgHeight = canvas.height;

        const imageData = ctx.getImageData(0, 0, imgWidth, imgHeight);
        const data = imageData.data;

        const getColorIndicesForCoord = (x, y, width) => {
            const red = y * (width * 4) + x * 4;
            return [red, red + 1, red + 2, red + 3];
        };

        for (let i = 0; i < data.length; i += 4) {
            data[i] = data[i] + 50 > 255 ? 255 : data[i] + 50 ; // red
            data[i + 1] = data[i + 1] + 50 > 255 ? 255 : data[i + 1] + 50 ; // green
            data[i + 2] = data[i + 2] + 50 > 255 ? 255 : data[i + 2] + 50 ; // blue
        }

        ctx.putImageData(imageData, 0, 0);
        */
        

        // SOLUTION N°2 : double boucle ou boucles imbriquées, sur chaque pixel de l'image
        
        // --- Q6a)
        const imgWidth = canvas.width;
        const imgHeight = canvas.height;
        
        // --- Q6b)
        // On récupère les valeurs rgba de tous les pixels de l'image
        const imageData = ctx.getImageData(0, 0, imgWidth, imgHeight);
        const data = imageData.data;
        
        // --- Q6c)
        const getColorIndicesForCoord = (x, y, width) => {
            const red = y * (width * 4) + x * 4;
            return [red, red + 1, red + 2, red + 3];
        };
        
        // --- Q6d)
        const [redIndex, greenIndex, blueIndex, alphaIndex] = getColorIndicesForCoord(0, 10, imgWidth);
        console.log('VALEURS (0,10)',data[redIndex], data[blueIndex], data[greenIndex])

        // --- Q6e) + Q6f)
        let numLigne=0;
        while (numLigne<imgHeight) {
            let numPixel=0;
            while (numPixel<imgWidth) {
                const [redIndex, greenIndex, blueIndex, alphaIndex] = getColorIndicesForCoord(numPixel, numLigne, imgWidth);

                data[redIndex] = data[redIndex] + 50 > 255 ? 255 : data[redIndex] + 50 ;
                data[greenIndex] = data[greenIndex] + 50 > 255 ? 255 : data[greenIndex] + 50 ;
                data[blueIndex] = data[blueIndex] + 50 > 255 ? 255 : data[blueIndex] + 50 ;

                numPixel++;
            }
            numLigne++;
        }

        // --- Q6g)
        ctx.putImageData(imageData, 0, 0);
        


        // SOLUTION N°3 : simple boucle sur l’ensemble des positions de pixels
        /*
        const imgWidth = canvas.width;
        const imgHeight = canvas.height;

        const imageData = ctx.getImageData(0, 0, imgWidth, imgHeight);
        const data = imageData.data;

        const getColorIndicesForCoord = (x, y, width) => {
            const red = y * (width * 4) + x * 4;
            return [red, red + 1, red + 2, red + 3];
        };

        let numLigne = 0;
        let numColonne = 0;
        while((numColonne < imgWidth) && (numLigne < imgHeight)) {
            const [redIndex, greenIndex, blueIndex, alphaIndex] = getColorIndicesForCoord(numColonne, numLigne, imgWidth);

            data[redIndex] = data[redIndex] + 50 > 255 ? 255 : data[redIndex] + 50 ;
            data[greenIndex] = data[greenIndex] + 50 > 255 ? 255 : data[greenIndex] + 50 ;
            data[blueIndex] = data[blueIndex] + 50 > 255 ? 255 : data[blueIndex] + 50 ;

            numColonne++;
            // En fin de ligne, on passe au début de la ligne suivante
            if(numColonne == imgWidth) {
                numLigne++;
                numColonne = 0;
            }
        }
        ctx.putImageData(imageData, 0, 0);
        */


        // ==== Q7. ==== //
        function dessineBarreImage(contexte, numeroBarre, hauteurHistogramme, hauteurBarre, largeurBarre, espacementBarre, imageSource) {
                const xBarre = numeroBarre * largeurBarre + numeroBarre * espacementBarre;
                
                // On récupère les données de l'image source correspondant à la largeur et à la hauteur de l'histogramme
                const imageData = imageSource.getImageData(0, 0, contexte.width, contexte.height);
                const data = imageData.data;

                // On récupère les données de l'image de l'histogramme
                histogramImageData = contexte.getImageData(0, 0, contexte.width, contexte.height);
                
                // On dessine la barre pixel par pixel en partant des coordonnées de son point en haut à gauche
                let x = xBarre;
                let y = hauteurHistogramme-hauteurBarre;
                // Tant qu'on n'a pas fini de traiter tous les pixels de la barre
                while((x < xBarre+largeurBarre) && (y < hauteurHistogramme)){
                    // On récupère la position des luminosités du pixel (x,y) dans les données de l'image de l'histogramme
                    const [redIndex, greenIndex, blueIndex, alphaIndex] = getColorIndicesForCoord(x, y, contexte.width);
                    // On copie les données du pixel (x,y) depuis l'image source
                    histogramImageData.data[redIndex] = data[redIndex];
                    histogramImageData.data[greenIndex] = data[greenIndex];
                    histogramImageData.data[blueIndex] = data[blueIndex];
                    histogramImageData.data[alphaIndex] = data[alphaIndex];
                    // On passe au pixel suivant
                    x++;
                    if(x == xBarre+largeurBarre){
                        // En fin de ligne, on passe au début de la ligne suivante
                        x=xBarre;
                        y++;
                    }
                }
                // On redessine l'histogramme à partir des données de l'image de l'histogramme
                contexte.putImageData(histogramImageData, 0, 0);
            }
            
        // Q7 : Dessin de l'histogramme en reprenant les couleurs d'une image source
        function dessineHistogrammeImage(contexte, largeurHistogramme, hauteurHistogramme, donnees, largeurBarre, espacementBarre, imageSource) {
            dessineAxes(contexte, largeurHistogramme, hauteurHistogramme);
            donnees.forEach((valeur, index) => {
                dessineBarreImage(contexte, index, hauteurHistogramme, valeur, largeurBarre, espacementBarre, imageSource);
            });
        }

        // Q7 : Recréation de l'histogramme en utilisant les couleurs d'une image comme texture des barres
        const canvasHistogramme = document.getElementById("canvas");
        const ctxHistogramme = canvasHistogramme.getContext("2d");
        ctxHistogramme.width=canvasHistogramme.width;
        ctxHistogramme.height=canvasHistogramme.height;

        dessineHistogrammeImage(ctxHistogramme, 100, 100, [100,50,90,10,50], 10, 10, ctx);


        // ==== QUESTION BONUS. REFACTORISER LES FONCTIONS DESSINEHISTOGRAMME ET DESSINEBARRE ==== //
        function dessineBarreRefactorise(contexte, numeroBarre, hauteurHistogramme, hauteurBarre, largeurBarre, espacementBarre, couleurOuImageSource) {
            const xBarre = numeroBarre * largeurBarre + numeroBarre * espacementBarre;

            // Q Bonus : si couleurOuImageSource est une chaine de caractère, alors on sait que c'est une couleur plutôt qu'une image
            if(typeof couleurOuImageSource === 'string') {
                contexte.globalAlpha = 0.5;
                contexte.fillStyle = couleurOuImageSource;
                // Q4 : dessin d'un rectangle
                contexte.fillRect(xBarre, hauteurHistogramme-hauteurBarre, largeurBarre, hauteurBarre);
            }
            else {
                const imageData = couleurOuImageSource.getImageData(0, 0, contexte.width, contexte.height);
                const data = imageData.data;

                histogramImageData = contexte.getImageData(0, 0, contexte.width, contexte.height);

                let x = xBarre;
                let y = hauteurHistogramme-hauteurBarre;
                while((x < xBarre+largeurBarre) && (y < hauteurHistogramme)){
                    const [redIndex, greenIndex, blueIndex, alphaIndex] = getColorIndicesForCoord(x, y, contexte.width);

                    histogramImageData.data[redIndex] = data[redIndex];
                    histogramImageData.data[greenIndex] = data[greenIndex];
                    histogramImageData.data[blueIndex] = data[blueIndex];
                    histogramImageData.data[alphaIndex] = data[alphaIndex];

                    x++;
                    if(x == xBarre+largeurBarre){
                        x=xBarre;
                        y++;
                    }
                }
                contexte.putImageData(histogramImageData, 0, 0);
            }
        }

        function dessineHistogrammeRefactorise(contexte, largeurHistogramme, hauteurHistogramme, donnees, largeurBarre, espacementBarre, couleurOuImageSource = "blue") {
            dessineAxes(contexte, largeurHistogramme, hauteurHistogramme);

            donnees.forEach((valeur, index) => {
                dessineBarreRefactorise(contexte, index, hauteurHistogramme, valeur, largeurBarre, espacementBarre, couleurOuImageSource);
            });
        }
        dessineHistogrammeRefactorise(ctxHistogramme, 100, 100, [100,50,90,10,50], 10, 10, ctx)
        // dessineHistogrammeRefactorise(ctxHistogramme, 100, 100, [100,50,90,10,50], 10, 10, "rgb(0,255,0)")
    });
});